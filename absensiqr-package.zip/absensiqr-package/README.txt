ABSENSIQR SERVER
================
1. pip install -r requirements.txt
2. python server.py
3. Buka http://localhost:5000

Password admin default: admin123 (ganti via env ADMIN_PASSWORD)
Lihat PANDUAN-AbsensiQR.html untuk panduan deploy online.
