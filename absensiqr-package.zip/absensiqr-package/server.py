# -*- coding: utf-8 -*-
"""
AbsensiQR Server — Backend untuk 2000+ pengguna
Jalankan:  python server.py   (butuh: pip install flask)
"""
from flask import Flask, request, jsonify, send_from_directory, Response
import sqlite3, os, datetime, csv, io, secrets

app = Flask(__name__, static_folder='static', static_url_path='')
BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, 'absensi.db')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'admin123')  # ganti via env var di server
PORT = int(os.environ.get('PORT', 5000))
TOKENS = set()  # sesi admin (memori)

def db():
    con = sqlite3.connect(DB, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA journal_mode=WAL')  # tahan banyak akses bersamaan
    return con

def init():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS mahasiswa(
        nim TEXT PRIMARY KEY,
        nama TEXT NOT NULL,
        jurusan TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS absensi(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nim TEXT NOT NULL,
        tanggal TEXT NOT NULL,
        masuk TEXT,
        pulang TEXT,
        UNIQUE(nim, tanggal)
    );
    CREATE INDEX IF NOT EXISTS idx_abs_tgl ON absensi(tanggal);
    """)
    con.commit(); con.close()

init()
today = lambda: datetime.date.today().isoformat()
now   = lambda: datetime.datetime.now().strftime('%H:%M')

def admin_ok():
    return request.headers.get('X-Admin-Token') in TOKENS

# ---------- FRONTEND ----------
@app.get('/')
def index():
    return send_from_directory('static', 'index.html')

# ---------- API MAHASISWA ----------
@app.post('/api/register')
def register():
    d = request.get_json(force=True)
    nama = (d.get('nama') or '').strip()
    nim  = (d.get('nim') or '').strip()
    jur  = (d.get('jurusan') or '').strip()
    if not (nama and nim and jur):
        return jsonify({'error': 'Lengkapi semua field'}), 400
    con = db()
    try:
        con.execute('INSERT INTO mahasiswa(nim,nama,jurusan) VALUES(?,?,?)', (nim,nama,jur))
    except sqlite3.IntegrityError:
        con.execute('UPDATE mahasiswa SET nama=?, jurusan=? WHERE nim=?', (nama,jur,nim))
    con.commit(); con.close()
    return jsonify({'ok': True})

@app.get('/api/mahasiswa')
def list_mhs():
    con = db()
    rows = con.execute('SELECT nim,nama,jurusan FROM mahasiswa ORDER BY nama').fetchall()
    con.close()
    return jsonify([dict(r) for r in rows])

@app.delete('/api/mahasiswa/<nim>')
def del_mhs(nim):
    if not admin_ok():
        return jsonify({'error': 'Unauthorized'}), 401
    con = db()
    con.execute('DELETE FROM mahasiswa WHERE nim=?', (nim,))
    con.execute('DELETE FROM absensi WHERE nim=?', (nim,))
    con.commit(); con.close()
    return jsonify({'ok': True})

# ---------- API ABSEN ----------
@app.post('/api/absen')
def absen():
    d = request.get_json(force=True)
    nim  = (d.get('nim') or '').strip()
    mode = d.get('mode', 'masuk')
    con = db()
    m = con.execute('SELECT * FROM mahasiswa WHERE nim=?', (nim,)).fetchone()
    if not m:
        con.close()
        return jsonify({'error': 'NIM "' + nim + '" tidak terdaftar'}), 404
    tgl, jam = today(), now()
    rec = con.execute('SELECT * FROM absensi WHERE nim=? AND tanggal=?', (nim, tgl)).fetchone()
    if mode == 'masuk':
        if rec and rec['masuk']:
            con.close()
            return jsonify({'error': m['nama'] + ' sudah absen MASUK pukul ' + rec['masuk']}), 409
        if rec:
            con.execute('UPDATE absensi SET masuk=? WHERE nim=? AND tanggal=?', (jam,nim,tgl))
        else:
            con.execute('INSERT INTO absensi(nim,tanggal,masuk) VALUES(?,?,?)', (nim,tgl,jam))
        con.commit(); con.close()
        return jsonify({'ok': True, 'nama': m['nama'], 'jam': jam})
    else:  # pulang
        if not rec or not rec['masuk']:
            con.close()
            return jsonify({'error': m['nama'] + ' belum absen masuk hari ini'}), 409
        if rec['pulang']:
            con.close()
            return jsonify({'error': m['nama'] + ' sudah absen PULANG pukul ' + rec['pulang']}), 409
        con.execute('UPDATE absensi SET pulang=? WHERE nim=? AND tanggal=?', (jam,nim,tgl))
        con.commit(); con.close()
        return jsonify({'ok': True, 'nama': m['nama'], 'jam': jam})

# ---------- API REKAP ----------
@app.get('/api/rekap')
def rekap():
    tgl = request.args.get('tanggal') or today()
    con = db()
    rows = con.execute("""SELECT m.nim, m.nama, m.jurusan, a.masuk, a.pulang
        FROM mahasiswa m LEFT JOIN absensi a
        ON a.nim = m.nim AND a.tanggal = ? ORDER BY m.nama""", (tgl,)).fetchall()
    con.close()
    return jsonify({'tanggal': tgl, 'data': [dict(r) for r in rows]})

@app.get('/api/export.csv')
def export_csv():
    tgl = request.args.get('tanggal') or today()
    con = db()
    rows = con.execute("""SELECT m.nama, m.nim, m.jurusan, a.masuk, a.pulang
        FROM mahasiswa m LEFT JOIN absensi a
        ON a.nim = m.nim AND a.tanggal = ? ORDER BY m.nama""", (tgl,)).fetchall()
    con.close()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(['Nama', 'NIM', 'Jurusan', 'Jam Masuk', 'Jam Pulang', 'Tanggal'])
    for r in rows:
        w.writerow([r['nama'], r['nim'], r['jurusan'], r['masuk'] or '-', r['pulang'] or '-', tgl])
    return Response('\ufeff' + buf.getvalue(), mimetype='text/csv',
        headers={'Content-Disposition': 'attachment; filename=absensi_' + tgl + '.csv'})

# ---------- ADMIN ----------
@app.post('/api/admin/login')
def admin_login():
    pwd = (request.get_json(force=True).get('password') or '')
    if pwd == ADMIN_PASSWORD:
        tok = secrets.token_hex(16)
        TOKENS.add(tok)
        return jsonify({'ok': True, 'token': tok})
    return jsonify({'error': 'Password salah'}), 401

@app.post('/api/admin/reset-absensi')
def reset_absensi():
    if not admin_ok():
        return jsonify({'error': 'Unauthorized'}), 401
    con = db()
    con.execute('DELETE FROM absensi WHERE tanggal=?', (today(),))
    con.commit(); con.close()
    return jsonify({'ok': True})

@app.post('/api/admin/reset-semua')
def reset_semua():
    if not admin_ok():
        return jsonify({'error': 'Unauthorized'}), 401
    con = db()
    con.execute('DELETE FROM absensi')
    con.execute('DELETE FROM mahasiswa')
    con.commit(); con.close()
    return jsonify({'ok': True})

if __name__ == '__main__':
    print('Server berjalan di http://0.0.0.0:' + str(PORT) + '  (admin password: ' + ADMIN_PASSWORD + ')')
    app.run(host='0.0.0.0', port=PORT, threaded=True)
